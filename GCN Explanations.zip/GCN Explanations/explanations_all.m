load modelGCN.mat
indx=13;

test_features = all_features(idxs,:);
train_features = all_features(idxt,:);

[test_main, class_pre]=max(dlYPredTest(indx,:)) % main prediction find max
[test_main_min, class_pre_min]=min(dlYPredTest(indx,:)); % main prediction find max

all_pre=zeros(1,3);          % contrastive class  
all_pre(1,:)=(dlYPredTest(indx,:));
B = sort(all_pre, 'descend');
counterf = B(2);
counterf_in=find(all_pre==counterf);

%Min max for main nodes MCT and THV in all dataset
minTest_main_node=min(all_features)';
maxTest_main_node=max(all_features)';

% % % 

nan_value=NaN(13,1);
min_max_main=[test_features(indx,:)' minTest_main_node maxTest_main_node nan_value];
test_case_main_node=round(test_features(indx,:),2); %MCT and THV IMAGE

%%%%%%%%%%%%%%%%%%%%
sz= size(test_case_main_node,2);
szj=size(min_max_main,2);
main_node_pre=zeros(2,szj);
cont_node_pre2=zeros(2,szj);
cont_node_pre3=zeros(2,szj);

for i = 1:sz
    for j = 1:szj
      dlXTestm_new=test_features;
      value=test_case_main_node;
      value(i)= min_max_main(i,j);
      dlXTestm_new(indx,i)= value(i);
      dlXTestm_new = normalizeFeatures(dlXTestm_new,train_features);
      dlYPredTest1 = model1(dlXTestm_new, adjacencyTest, parameters, indx);
      test2=(dlYPredTest1(indx,counterf_in));
      test1=(dlYPredTest1(indx,class_pre)); %prediction 
      test3=(dlYPredTest1(indx,class_pre_min));
      main_node_pre(i,j)=test1;
      cont_node_pre2(i,j)=test2;
      cont_node_pre3(i,j)=test3;
    end
end

maxs=zeros(1,sz); %max for each feature
ind =zeros(1,sz); %feature index 3=max 2=min 1=original

for idx = 1:sz
    
infl = pdist (main_node_pre(idx,:)');
y = squareform(infl);
[maxs(idx), ind(idx)] = max(y(1,:));

end

%_____________calculate impact
[mins, mins_f]=cal_imp(main_node_pre); %main
[mins_c, mins_f_c]=cal_imp(cont_node_pre2); %cont

mins_new=main_node_pre(:,1)- main_node_pre(:,4);
mins_new = normalize(mins_new);

mins_cont_new=cont_node_pre2(:,1)- cont_node_pre2(:,4);
mins_cont_new = normalize(mins_cont_new);

mins2_cont_new=cont_node_pre3(:,1)- cont_node_pre3(:,4);
mins2_cont_new = normalize(mins2_cont_new);

%%Clusters
minmaxs=min_max_main';
v=test_case_main_node;

Cluster={minmaxs(1:4,1:2)',minmaxs(1:4,3:4)',minmaxs(1:4,5:7)',minmaxs(1:4,8:10)',minmaxs(1:4,11:13)'}; 

[minmaxs_cluster1,maxs1,inmax1,mins_c1]=clusters(v,1,2,Cluster,1,test_features,indx,train_features,adjacencyTest,parameters,class_pre);
[minmaxs_cluster2,maxs2,inmax2,mins_c2]=clusters(v,3,4,Cluster,2,test_features,indx,train_features,adjacencyTest,parameters,class_pre);
[minmaxs_cluster3,maxs3,inmax3,mins_c3]=clusters(v,5,7,Cluster,3,test_features,indx,train_features,adjacencyTest,parameters,class_pre);
[minmaxs_cluster4,maxs4,inmax4,mins_c4]=clusters(v,8,10,Cluster,4,test_features,indx,train_features,adjacencyTest,parameters,class_pre);
[minmaxs_cluster5,maxs5,inmax5,mins_c5]=clusters(v,11,13,Cluster,5,test_features,indx,train_features,adjacencyTest,parameters,class_pre);
minmaxs_cluster=[minmaxs_cluster1; minmaxs_cluster2; minmaxs_cluster3; minmaxs_cluster4; minmaxs_cluster5];
maxs_cluster=[maxs1 maxs2 maxs3 maxs4 maxs5];
mins_cluster=[mins_c1 mins_c2 mins_c3 mins_c4 mins_c5];
maxs_cluster=maxs_cluster*100;

clusters_value=(minmaxs_cluster(:,1)- minmaxs_cluster(:,4));
clusters_value = normalize(clusters_value);
clusters_im=abs(clusters_value);
% clusters_im=clusters_value(clusters_value>0);
% [c_values, ind_cluster] = intersect(clusters_value,clusters_im);
% %%%%%%%%%%%%%%%%%%%%%% Edge Features 
edge_pre_tem = zeros(1,numOut);

for m=1:numOut
    
class_test=labelst(idxs);
edge_class=adjacencyTest(:,indx);

for k = 1:size(class_test,1)
    if class_test(k)==m
        edge_class(k)=0;
    end
end

adjacencyTest_new = adjacencyTest;
adjacencyTest_new(:,indx)=edge_class;
adjacencyTest_new(indx,:)=edge_class;
dlYPredTest3 = model(dlXTest, adjacencyTest_new, parameters);
test3=(dlYPredTest3(indx,class_pre)); %prediction 
edge_pre_tem(m)=test3;

end

edge_pre = [main_node_pre(1) edge_pre_tem];
  
edge_infl = pdist (edge_pre');
edge_infl = squareform(edge_infl);
edge_dist = (edge_infl(2:4))*10; %*10 to complete the pie

% edge_dist=1-edge_pre_tem;

%%%%%%%%%%%%%%%      Figures  %%%%%%%%%%%%%%%%%%%
titleString = compose("The machine learning system thinks it is %s (%.2f). \n The counterfactual case is %s (%.2f).\n ",char(classes(class_pre)),minmaxs_cluster1(1),char(classes(counterf_in)),counterf); %max_score topScores(10)
sgtitle(sprintf(join(titleString, "; ")), 'FontSize', 9);

%__________________________________________________Individual Features

f =categorical({'Age','Gender','MCT','THV','Memory','EXF','Language','GD Scale','MoCA','MMSE','Amyloid positivity','Tau','PHS'});
f =reordercats(f,{'Age','Gender','MCT','THV','Memory','EXF','Language','GD Scale','MoCA','MMSE','Amyloid positivity','Tau','PHS'});
subplot(2,3,1); b=barh(f,mins_new,'FaceColor','#77AC30','EdgeColor','none');
xtips1 = b.YEndPoints;
ytips1 = b.XEndPoints;
label_values=test_case_main_node;
if label_values(8)>10
    label_values(8)=label_values(8)-10;
else
    label_values(8)=label_values(8)+9;
end

label_values(11:end)=label_values(11:end)*-1;
labels1 = string(label_values);

text(xtips1,ytips1,labels1,'VerticalAlignment','middle')
title('Attributes and their estimated impact')
set(gca,'box','off')

%__________________________________________________Each Group
subplot(2,3,2); p=pie(clusters_im);
title('Influence of each data group for the patient')
pText = findobj(p,'Type','text');
percentValues = get(pText,'String'); 
labels = {'Demographic:';'Medical Imaging:';'Cognitive Test:';'NT:';'Biomarker:'};
% labels_c=labels(ind_cluster);
combinedtxt = strcat(labels,percentValues);


for k = 1:size(clusters_im)
pText(k).String = combinedtxt(k);

end

colormap([0.7 0.8 0.1;      %// red
          0.7 0.9 0.4;      %// green
          0.7 0.9 0.9;
          0.7 1 0.3;  
          0.7 1 0.8;]);
%________________________________________________ Patient Similarity Edges
subplot(2,3,5); p2=pie(edge_dist);
title('Patient similarity based on cognitive scores')
pText2 = findobj(p2,'Type','text');
percentValues2 = get(pText2,'String'); 
labels_p = {'NC:';'MCI:';'AD:'};

combinedtxt2 = strcat(labels_p,percentValues2);
pText2(1).String = combinedtxt2(1);
pText2(2).String = combinedtxt2(2);
pText2(3).String = combinedtxt2(3);

%__________________________________________________ Text Exp  


dim = [.13 0.17 .20 .25];
%[find_f, f_indx]=sort(maxs,'descend')
[find_f, f_indx]=sort(mins_new,'descend');
feature_cat = ["Age" "Gender" "Mean cortical thickness" "Total hippocampus volume" "Memory score" "EXF" "Language score"...
               "GD Scale" "MoCa score" "Mini-mental state score" "Amyloid" "Tau" "Polygenic hazard score"];

[find_c, find_min_max_ind]=text_explanation(label_values, feature_cat, f_indx);

% feature_im=mins_new(mins_new>0);
% [f_values, ind_f] = intersect(mins_new,feature_im);

supp_class1=[find_c(1:6);string(find_min_max_ind(1:6))];

% Loop
str = compose("Measures supporting %s: \n-%s is %s. \n-%s is %s. \n-%s is %s. \n-%s is %s. \n-%s is %s. \n-%s is %s.",...
char(classes(class_pre)), supp_class1(1),supp_class1(2),supp_class1(3),supp_class1(4),...
supp_class1(5),supp_class1(6),supp_class1(7),supp_class1(8),supp_class1(9),supp_class1(10),...
supp_class1(11),supp_class1(12));
% % str3=[str str2];
annotation('textbox',dim,'String',str)

%______________________________________Contrastive Figure

f =categorical({'Age','Gender','MCT','THV','Memory','EXF','Language','GD Scale','MoCa','MM score','Amyloid positivity','Tau','PHS'});
f =reordercats(f,{'Age','Gender','MCT','THV','Memory','EXF','Language','GD Scale','MoCa','MM score','Amyloid positivity','Tau','PHS'});
subplot(2,3,3); b=barh(f,mins_cont_new,'FaceColor','#77AC30','EdgeColor','none');
xtips1 = b.YEndPoints;
ytips1 = b.XEndPoints;
labels1 = string(label_values);
text(xtips1,ytips1,labels1,'VerticalAlignment','middle')
title('Attributes and their estimated impact')
set(gca,'box','off')

%____________________________________________Contrastive text
% second biggest in prediction as counterfactual 

dim2 = [.71 0.19 .20 .25];

[find_f_c, f_indx_c]=sort(mins_cont_new,'descend');
% feature_cat = ["Age" "Gender" "Mean cortical thickness" "Total hippocampus volume" "Memory score" "Language score"...
%                "MoCa score" "Mini-mental state score" "Amyloid positivity" "Tau" "Polygenic hazard score"];

[find_c_c, find_min_max_ind_cont]=text_explanation(label_values, feature_cat, f_indx_c);
% levels=[ind; (mins_f_c*100)'; mins_c'];

supp_class_c=[find_c_c(1:6);string(find_min_max_ind_cont(1:6))];

% Loop
str_c = compose("Measures supporting %s: \n-%s is %s. \n-%s is %s. \n-%s is %s. \n-%s is %s. \n-%s is %s. \n-%s is %s.",...
char(classes(counterf_in)), supp_class_c(1),supp_class_c(2),supp_class_c(3),supp_class_c(4),...
supp_class_c(5),supp_class_c(6),supp_class_c(7),supp_class_c(8),supp_class_c(9),supp_class_c(10),...
supp_class_c(11),supp_class_c(12));

annotation('textbox',dim2,'String',str_c)

% fig_data=[test_case_main_node; percentValues; mins'; percentValues2; mins_c'];
f_names=string(f)';
%pValues

table1=table(f_names,label_values');
table2=table(f_names,round(mins_new,2));
table3=table(labels,percentValues);
table4=table(labels_p,percentValues2);
table5=table([titleString; string(str); string(str_c)]);
table6=table(f_names,round(mins_cont_new,2));
table7=table(labels,clusters_value);
% strs_all=[str; str_c];
filename='case_13.xlsx';
writetable(table1,filename,'Sheet',1,'Range','A1');
writetable(table2,filename,'Sheet',2,'Range','A1');
writetable(table3,filename,'Sheet',3,'Range','A1');
writetable(table4,filename,'Sheet',4,'Range','A1');
writetable(table5,filename,'Sheet',5,'Range','A1');
writetable(table6,filename,'Sheet',6,'Range','A1');
writetable(table7,filename,'Sheet',7,'Range','A1');
