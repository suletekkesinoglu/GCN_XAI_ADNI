function dlY = model(dlX, A, parameters)

% Normalize adjacency matrix
L = normalizeAdjacency(A);
L=real(L);
Z1 = dlX;
Z2 = L * Z1 * parameters.W1;
%Z1 = dlX(:,1)+ dlX(:,2); %...63%
Z=sum(Z1, 2); % instead Z2 = relu(Z2)+Z1(:,2);
Z2 = relu(Z2)+Z;
% Z2 = relu(Z2)+Z1(:,2);

Z3 = L * Z2 * parameters.W2;
Z3 = relu(Z3) + Z2;

Z4 = L * Z3 * parameters.W3;
dlY = softmax(Z4, 'DataFormat', 'BC');

end