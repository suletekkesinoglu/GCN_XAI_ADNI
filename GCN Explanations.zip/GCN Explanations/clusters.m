function [minmaxs_cluster, maxs, ind, mins] =clusters(v,row,col,c,cluster_in,test_features,indx,train_features,adjacencyTest,parameters,class_pre)

minmaxs_cluster=zeros(1,4);

for id = 1:4
    dlXTestm_new2=test_features;
    v(row:col)=c{1,cluster_in}(:,id);
    dlXTestm_new2(indx,:)= v;
    dlXTestm_new2 = normalizeFeatures(dlXTestm_new2,train_features);
    dlYPredTest2 = model_cluster(dlXTestm_new2, adjacencyTest, parameters, indx);
    test2=(dlYPredTest2(indx,class_pre)); %prediction 
    minmaxs_cluster(id)=test2;
end

f_mins=min(minmaxs_cluster);
f_maxs=max(minmaxs_cluster);
f_im=f_maxs-f_mins;
mins=(minmaxs_cluster(1)-f_mins);
mins(mins==0)=0.0001;
mins=mins./f_im;

infl = pdist (minmaxs_cluster');
y = squareform(infl);
[maxs, ind] = max(y(1,:));



end