function dlY = model1(dlX, A, parameters, indx)

% Normalize adjacency matrix
L = normalizeAdjacency(A);
L=real(L);
Z1 = dlX;

% Z2 = L * Z1;
% Z2=Z2*parameters.W1; %Z1 = dlX(:,1)+ dlX(:,2); %...63%
% Z=sum(Z1, 2); % instead Z2 = relu(Z2)+Z1(:,2);

m=zeros(222,13);
for jj=1:222
   
    for id = 1:13
        n=(L(jj,:).* Z1(:,id)');
        nonNanLocations = ~isnan(n); % Location of indexes that are good.
        cwithoutNans = n(nonNanLocations);
        m(jj,id)=sum(cwithoutNans,2);
    end
    
end

Z2 =m *parameters.W1;
nonNanLocationsZ1 = ~isnan(Z1(indx,:)); % Location of indexes that are good.
cwithoutNansZ1 = Z1(indx,nonNanLocationsZ1);
sumz1=sum(cwithoutNansZ1,2);

Z=sum(Z1, 2);
Z(indx)=sumz1;

Z2 = relu(Z2)+Z;
% Z2 = relu(Z2)+Z1(:,2);

Z3 = L * Z2 * parameters.W2;
Z3 = relu(Z3) + Z2;

Z4 = L * Z3 * parameters.W3;
dlY = softmax(Z4, 'DataFormat', 'BC');

end