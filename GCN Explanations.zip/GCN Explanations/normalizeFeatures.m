function feature_m = normalizeFeatures(feature_m,features)
feature=uint16(features);
% Get the mean and variance from the training data
meanFeatures = mean(feature);
featuree=single(feature);
varFeatures = var(featuree, 1);

% Standardize training, validation and test data

feature_m = (feature_m - meanFeatures)./sqrt(varFeatures);


end