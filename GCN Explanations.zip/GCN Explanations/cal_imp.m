function [mins,mins_f]=cal_imp(main_node_pre)
f_mins=min(main_node_pre(:,2), main_node_pre(:,3));
f_maxs=max(main_node_pre(:,2), main_node_pre(:,3));
f_im=f_maxs-f_mins;
mins_f=(main_node_pre(:,1)-f_mins);
mins_f(mins_f==0)=0.0001;
mins=mins_f./f_im;
mins(mins==1)=f_im(mins==1)*10; %effect of Amy/Gen
end