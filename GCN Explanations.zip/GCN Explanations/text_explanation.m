function [find_c, find_min_max_ind]=text_explanation(xRange, feature_cat, f_indx)

num_data=xlsread('edges-reverse2.xlsx',1);
    
ranges1={num_data(1:6,1:2), num_data(1:6,4:5), num_data(1:6,7:8), num_data(1:6,10:11),...
    num_data(1:6,13:14), num_data(1:6,16:17), num_data(1:6,19:20),...
    num_data(1:6,22:23), num_data(1:6,25:26), num_data(1:6,28:29), num_data(1:6,31:32),...
    num_data(1:6,34:35),num_data(1:6,37:38)};
   
% xRange=[76, 2, 2.91, 6.84, -0.25, 0.37, 62, 25, 1, 27.32, 1.32];

% r=ranges1{1,1};
ranges=zeros(1,13);

for jj=1:13
    r=ranges1{1,jj};
    for id = 1:6
        tem=r(id,:);
        ii = xRange(jj) >= tem(1) & xRange(jj) <= tem(2);
        if ii==1
            ranges(jj)=id;
        end
    end
    
end

ver_degrees=["mature" "young-old" "middle-old" "old-old" "very old" "very very old";
             "empty" "empty" "male" "female" "empty" "empty";
             "very low" "low" "nominal" "not so high" "high" "very high";
             "very low" "low" "nominal" "not so high" "high" "very high";
             "very low" "low" "nominal" "good" "high" "very high";
             "very low" "low" "normal" "good" "high" "very high";
             "very low" "low" "in border" "good" "high" "very high";
             "empty"  "normal" "in mild depressives range" "empty" "empty" "empty";
             "empty" "in severe dementia" "in moderate dementia" "in mild dementia" "in normal cognition" "empty";
             "empty" "in severe dementia" "in moderate dementia" "in mild dementia" "in normal cognition" "empty";
             "empty" "empty"  "negative" "positive" "empty" "empty";
             "empty" "empty"  "negative" "positive" "empty" "empty";
             "very low" "not so low" "little high" "little high" "high" "very high"]';

 d_names=string(13);  
%  d_names=num2str(d_names);
 for k=1:13      
 degrees=discretize(ranges(k),[1 2 3 4 5 6 7],'categorical', ver_degrees(:,k));
 d_names(k)=degrees;
 end

 
 find_c=feature_cat(f_indx); %rearrange names
 find_min_max_ind=d_names(f_indx); %rearrange degrees
 
%  supp_class1=[find_c(1:4);string(find_min_max_ind(1:4))];
end
 
 

% r = [1, 6; 6, 9; 10, 15];
% siz=size(r,1);
% ranges=zeros(1,2);
% for id = 1:siz
%     tem=r(id,:);
%     ii = xRange(1) >= tem(1) & xRange(1) <= tem(2)
%     if ii==1
%         ranges=id
%     end 
% end

