
T = readmatrix('data_adni.xlsx');
% T(any(isnan(T), 2), :) = [];
%T = rmoutliers(T);

all_features=[T(:,3),T(:,2),...% AGE GEN
              T(:,4),T(:,5),... % MCT THV
              T(:,6),T(:,7),T(:,8),... %MEM EXF LAN  
              T(:,9),T(:,10),T(:,11),... % GDScale MoCa MM 
              T(:,13),T(:,14),... %AMY TAU
              T(:,12)] %PHS 
                

Ad=[T(:,6),T(:,7),T(:,8)]; %MEM EXF LAN

%   Ad=T(:,6);m 

labelst=single(T(:,15));
[adjacency_we, features, class, idxt, idxv, idxs] = split_Data2(Ad,all_features, labelst);

data_index ={idxt,idxv,idxs}; 
adjacency=adjacencyedges(adjacency_we,data_index,labelst);

labels={'NC','MCI','AD'};
classesT = discretize(class{1},[1 2 3 4],'categorical',labels);
classesV = discretize(class{2},[1 2 3 4],'categorical',labels);
classesS = discretize(class{3},[1 2 3 4],'categorical',labels);

features = normalizeFeatures(features);
classes=cellstr(labels)'; 

%.............
featureTrain = features{1};
adjacencyTrain = adjacency{1};
targetTrain = class{1};

featureValidation = features{2};
adjacencyValidation = adjacency{2};
targetValidation = class{2};

numInputFeatures = size(featureTrain,2)
numHiddenFeatureMaps = 32;
numOutputFeatures = numel(labels)

sz = [numInputFeatures numHiddenFeatureMaps];
numOut = numHiddenFeatureMaps;
numIn = numInputFeatures;
parameters.W1 = initializeGlorot(sz,numOut,numIn,'double');

sz = [numHiddenFeatureMaps numHiddenFeatureMaps];
numOut = numHiddenFeatureMaps;
numIn = numHiddenFeatureMaps;
parameters.W2 = initializeGlorot(sz,numOut,numIn,'double');

sz = [numHiddenFeatureMaps numOutputFeatures];
numOut = numOutputFeatures;
numIn = numHiddenFeatureMaps;
parameters.W3 = initializeGlorot(sz,numOut,numIn,'double');
% 
numEpochs = 100;
learnRate = 0.01;
validationFrequency = 5;
plots = "training-progress";
executionEnvironment = "auto";

if plots == "training-progress"
   figure
    
    % Accuracy.
    subplot(2,1,1)
    lineAccuracyTrain = animatedline('Color',[0 0.447 0.741]);
    lineAccuracyValidation = animatedline( ...
        'LineStyle','--', ...
        'Marker','o', ...
        'MarkerFaceColor','black');
    ylim([0 1])
    xlabel("Epoch")
    ylabel("Accuracy")
    grid on
    
    % Loss.
    subplot(2,1,2)
    lineLossTrain = animatedline('Color',[0.85 0.325 0.098]);
    lineLossValidation = animatedline( ...
        'LineStyle','--', ...
        'Marker','o', ...
        'MarkerFaceColor','black');
    ylim([0 inf])
    xlabel("Epoch")
    ylabel("Loss")
    grid on
end

trailingAvg = [];
trailingAvgSq = [];

dlX = dlarray(featureTrain);
dlXValidation = dlarray(featureValidation);


if (executionEnvironment == "auto" && canUseGPU) || executionEnvironment == "gpu"
    dlX = gpuArray(dlX);
end
% if canUseGPU
%     XTrain = gpuArray(XTrain);
% end

T2 = onehotencode(classesT, 2, 'ClassNames', labels);
TValidation = onehotencode(classesV, 2, 'ClassNames', labels);

%........................
start = tic;
% Loop over epochs.
% 
for epoch = 1:numEpochs
    
    % Evaluate the model gradients and loss using dlfeval and the
    % modelGradients function.
    [gradients, loss, dlYPred] = dlfeval(@modelGradients, dlX, adjacencyTrain, T2, parameters);
    loss2 = crossentropy(dlYPred, T2, 'DataFormat', 'BC');
    % Update the network parameters using the Adam optimizer.
    [parameters,trailingAvg,trailingAvgSq] = adamupdate(parameters,gradients, ...
        trailingAvg,trailingAvgSq,epoch,learnRate);
    
    % Display the training progress.
    if plots == "training-progress"
        subplot(2,1,1)
        D = duration(0,0,toc(start),'Format','hh:mm:ss');
        title("Epoch: " + epoch + ", Elapsed: " + string(D))

        % Loss.
        addpoints(lineLossTrain,epoch,double(gather(extractdata(loss))))
  
%        Accuracy score.
       score = accuracy(dlYPred, classesT, classes);
       addpoints(lineAccuracyTrain,epoch,double(gather(score)))

        drawnow

        % Display validation metrics.
        if epoch == 1 || mod(epoch,validationFrequency) == 0
            % Loss.
            dlYPredValidation = model(dlXValidation, adjacencyValidation, parameters);
            lossValidation = crossentropy(dlYPredValidation, TValidation, 'DataFormat', 'BC');
            addpoints(lineLossValidation,epoch,double(gather(extractdata(lossValidation))))

            % Accuracy score.
            scoreValidation = accuracy(dlYPredValidation, classesV, classes);
            addpoints(lineAccuracyValidation,epoch,double(gather(scoreValidation)))

            drawnow
        end
    end
end
