function features = normalizeFeatures(features)
feature=uint16(features{1});
% Get the mean and variance from the training data
meanFeatures = mean(feature);
featuree=single(feature);
varFeatures = var(featuree, 1);

% Standardize training, validation and test data
for i = 1:3
    features{i} = (features{i} - meanFeatures)./sqrt(varFeatures);
end

end