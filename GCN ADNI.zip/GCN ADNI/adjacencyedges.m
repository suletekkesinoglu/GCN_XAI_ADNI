function edgedata2=adjacencyedges(adjacency,idxt,labelst)
edgedata2 = cell(1,3);

for k=1:3
    
edgedata=adjacency{k};
datasize = size(edgedata,1)
class_test=labelst(idxt{k});

egdata=zeros(datasize,datasize);

for i = 1:datasize
    for j = 1:datasize
         if class_test(i)==class_test(j)
             egdata(i,j)=edgedata(i,j);
         else
             egdata(i,j)=edgedata(i,j)*0.85; %0.9 72%accuracy
         end
    end
end

edgedata2{k}=egdata;

end
end