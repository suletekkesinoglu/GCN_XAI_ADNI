function [adjacency_split, features_split, labels_split, idxt, idxv, idxs] = split_Data2(adjacency_data, features, labels)

adjacency_split = cell(1,3);
features_split = cell(1,3);
labels_split = cell(1,3);
numdata = size(features, 1);

% Set initial random state for example reproducibility.
rng(0);
[idxTrain,idxValidation,idxTest] = trainingPartitions(numdata,[0.8 0.1 0.1]);
% Get training data
%idx = randperm(size(features, 1), floor(0.8*numdata));
idxt=idxTrain;
features_split{1} = features(idxt,:);

adjacency_data1=adjacencydata(adjacency_data(idxt,:));
adjacency_split{1} = adjacency_data1;
labels_split{1} = labels(idxt,:);


% Get validation data
%idx = randperm(size(features, 1), floor(0.1*numdata));
idxv=idxValidation;

features_split{2} = features(idxv,:);

adjacency_data2=adjacencydata(adjacency_data(idxv,:));
adjacency_split{2} = adjacency_data2;
labels_split{2} = labels(idxv,:);


% Get test data
%idx = randperm(size(features, 1), floor(0.1*numdata));
idxs=idxTest;

features_split{3} = features(idxs,:);

adjacency_data3=adjacencydata(adjacency_data(idxs,:));
adjacency_split{3} = adjacency_data3;
labels_split{3} = labels(idxs,:);

end