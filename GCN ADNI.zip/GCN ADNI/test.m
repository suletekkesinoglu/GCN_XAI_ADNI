
featureTest = features{3};
adjacencyTest = adjacency{3};
%targetTest = labels{3};

dlXTest = dlarray(featureTest);

dlYPredTest = model(dlXTest, adjacencyTest, parameters);
classesS = discretize(class{3},[1 2 3 4],'categorical',labels);

[scoreTest, predTest] = accuracy(dlYPredTest, classesS, classes);

prediction = onehotdecode(dlYPredTest, classes, 2);
prediction = categorical(prediction,{'NC','MCI','AD'},'Ordinal',true);

score = sum(prediction == classesS)/numel(classesS);
score2 = mean(prediction == classesS)

round(score,2)

figure
cm = confusionchart(classesS,prediction)
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';
cm.Title = 'Confusion Matrix';

save modelGCN

