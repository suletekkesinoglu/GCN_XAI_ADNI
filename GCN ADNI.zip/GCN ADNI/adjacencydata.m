function adjacency_data = adjacencydata(Ad)
sz=size(Ad,1);
adjacency_data=zeros(sz,sz);%size

for  i = 1:size(Ad,2)
    
Ad_d=(squareform((pdist(Ad(:,i)))));
%Ad_d=normalizeAdjacency(Ad_d);
adjacency_data=adjacency_data+Ad_d;

end
%adjacency_data = 0.1*(100-adjacency_data);
adjacency_data = 1-(mat2gray(adjacency_data));
adjacency_data = adjacency_data - diag(diag(adjacency_data)); %add zero diagnoal
 %  Weights? not normalized 
[row,col]=find(adjacency_data); %threshold? 
% [row,col]=find(adjacency_data>0.9);
size_n=size(row,1);
for  i = 1:size_n
    
adjacency_a=adjacency_data(row(i),col(i));
t(i)=adjacency_a;
end

adjacency_data = sparse(row,col,t);
adjacency_data = full(adjacency_data);


end